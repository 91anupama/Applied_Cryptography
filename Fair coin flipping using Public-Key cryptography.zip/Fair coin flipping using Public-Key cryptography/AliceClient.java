package diat.in;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.KeyPair;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JOptionPane;
import javax.xml.bind.DatatypeConverter;

public class AliceClient  extends Rsa{
	

	static KeyPair keypair;
	static String head="11";
	static String tail="00";
	public Rsa rsa;
	

	public static byte[] EncyprtionAlice(String text)throws Exception {
		 byte[] cipher = do_RSAEncryption( text, keypair.getPrivate());
		return cipher;
		
	}
	 public static void main(String[] args) throws Exception {
	 keypair= Rsa.generateRSAKkeyPair();
		//String eA = DatatypeConverter.printHexBinary(keypair.getPublic().getEncoded());
		//String dA=DatatypeConverter.printHexBinary( keypair.getPrivate().getEncoded());
		
		byte[] headCipher = EncyprtionAlice(head);
		byte[] tailCipher =EncyprtionAlice(tail);
		
		Integer head, tail,dA,eA,n;
		head=5;
		tail=10;
		dA=23;//private key
		eA=7;//public key
		n=187 ;
		List<Integer> msgarray = new ArrayList<>();
		msgarray.add(head);
		msgarray.add(tail);
		String serverAddress = "localhost";
		int serverPort = 9090;
		Socket s = new Socket(serverAddress, serverPort);
		PrintWriter out = new PrintWriter(s.getOutputStream(), true);
		BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
		String msg="";
		msg = input.readLine();
		System.out.println(msg);//5power 7mod 187=146/// 10 power 7 mod 187=10000000mod187=175
		String myname = "Alice";//40 power 23 mod 187=84
		while(true)
		{
		String toServer = JOptionPane.showInputDialog(null,"Send something");
		out.println("From "+myname+":"+toServer);
		msg = input.readLine();
		//Collections.shuffle(msgarray);
		//msg=msgarray.toString();
		System.out.println(msg);
		if (toServer.equals("#")) break;
		}
		out.close();
		input.close();
		s.close();
		System.exit(0);
	 }
}
