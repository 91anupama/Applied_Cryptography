package diat.in;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.security.KeyPair;

import javax.swing.JOptionPane;
import javax.xml.bind.DatatypeConverter;

public class BobClient extends Rsa {

	KeyPair keypair;
	public Rsa rsa;

	public KeyPair grnaratePublicPrivateKey() throws Exception {
		keypair = Rsa.generateRSAKkeyPair();
		return keypair;
	}

	String eB = DatatypeConverter.printHexBinary(keypair.getPublic().getEncoded());
	String dB = DatatypeConverter.printHexBinary(keypair.getPrivate().getEncoded());

	public static void main(String args[]) throws IOException {
		
		Integer dB,eB,n;
		
		dB=37;
		eB=13;
		n=77 ;
		String serverAddress = "localhost";
		int serverPort = 9090;
		Socket s = new Socket(serverAddress, serverPort);
		PrintWriter out = new PrintWriter(s.getOutputStream(), true);
		BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
		String msg="";
		msg = input.readLine();
		System.out.println(msg);
		String myname = "Bob";
		while(true)
		{
		String toServer = JOptionPane.showInputDialog(null,"Send something");
		out.println("From "+myname+":"+toServer);
		msg = input.readLine();
		System.out.println(msg);//146power 13mod77=40
		if (toServer.equals("#")) break;//84 power 37mod77=5
		}
		out.close();
		input.close();
		s.close();
		System.exit(0);
	}
}
